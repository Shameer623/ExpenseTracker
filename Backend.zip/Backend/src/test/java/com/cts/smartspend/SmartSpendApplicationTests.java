package com.cts.smartspend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartSpendApplicationTests {

	@Test
	void contextLoads() {
	}

}
