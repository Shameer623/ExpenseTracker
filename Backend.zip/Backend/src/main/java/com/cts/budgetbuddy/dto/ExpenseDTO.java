package com.cts.budgetbuddy.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
public class ExpenseDTO {
	
	private Long id;

    @NotNull(message = "Category ID should not be null")
    private Long categoryId;
    
    private Double amount;

    @NotBlank(message = "Provide proper description")
    private String description;

    @NotNull(message = "Date must be entered")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate date;

    @NotNull(message = "User ID should not be null")
    private Long userId;
    public ExpenseDTO(Long id, Double amount, String description, Long categoryId, Long userId, LocalDate date) {
        this.id = id;
        this.categoryId = categoryId;
        this.amount = amount;
        this.description = description;
        this.userId = userId;
        this.date = date;
    }

    
}
