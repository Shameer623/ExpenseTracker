package com.cts.budgetbuddy.serviceImpl;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.budgetbuddy.dto.BudgetDTO;
import com.cts.budgetbuddy.entity.Budget;
import com.cts.budgetbuddy.entity.Category;
import com.cts.budgetbuddy.exception.BudgetNotFoundException;
import com.cts.budgetbuddy.exception.CategoryNotFoundException;
import com.cts.budgetbuddy.exception.OverlappingBudgetException;
import com.cts.budgetbuddy.repo.BudgetRepo;
import com.cts.budgetbuddy.repo.CategoryRepo;
import com.cts.budgetbuddy.service.IBudgetService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BudgetService implements IBudgetService {

    @Autowired
    private BudgetRepo budgetRepo;

    @Autowired
    private CategoryRepo categoryRepo;

    @Override
    public List<BudgetDTO> getAllBudgets() {
        List<Budget> budgetList = budgetRepo.findAll(); // fetch all budget
        if (budgetList.isEmpty()) {
            throw new BudgetNotFoundException("No Budget found");
        }
        return convertToBudgetDTO(budgetList); // convert to DTO before returning
    }


    @Override
    @Transactional
    public BudgetDTO setBudget(BudgetDTO budgetDTO) {
    	//checks for overlapping budgets in same category and time range
        List<Budget> overlappingBudgets = budgetRepo.findOverlappingBudgets(
                budgetDTO.getCategoryId(), budgetDTO.getStartDate(), budgetDTO.getEndDate());

        if (!overlappingBudgets.isEmpty()) {
            throw new OverlappingBudgetException("A budget already exists for the same category with overlapping dates.");
        }

        Category category = categoryRepo.findById(budgetDTO.getCategoryId())
                .orElseThrow(() -> new CategoryNotFoundException("Category not found"));

        Budget budget = new Budget();
        budget.setCategory(category);
        budget.setAmount(budgetDTO.getAmount());
        budget.setStartDate(budgetDTO.getStartDate());
        budget.setEndDate(budgetDTO.getEndDate());
        Budget savedBudget = budgetRepo.save(budget);//saves the budget
        return convertToBudgetDTO(savedBudget); //return as DTO
    }

    @Override
    public BudgetDTO getBudgetById(Long id) {
        Budget budget = budgetRepo.findById(id)
                .orElseThrow(() -> new BudgetNotFoundException("Budget is not found"));
        return convertToBudgetDTO(budget);
    }

    @Override
    public List<BudgetDTO> getBudgetByCategoryId(Long id) {
        if (!categoryRepo.existsById(id)) {
            throw new CategoryNotFoundException("Category is not found");
        }
        List<Budget> budget = budgetRepo.findAllByCategoryId(id);
        if (budget.isEmpty()) {
            throw new BudgetNotFoundException("Budget is not found");
        }
        return convertToBudgetDTO(budget);
    }

    @Override
    @Transactional
    public BudgetDTO updateBudget(Long id, BudgetDTO budgetDTO) {
    	
        Budget budget = getBudgetEntityById(id); //helper method to fetch the budget
      //checks for overlapping budgets except the current budget
        List<Budget> overlappingBudgets = budgetRepo.findOverlappingBudgets(
                budgetDTO.getCategoryId(), budgetDTO.getStartDate(), budgetDTO.getEndDate());

        if (!overlappingBudgets.isEmpty() && !overlappingBudgets.get(0).getId().equals(id)) {
            throw new OverlappingBudgetException("A budget already exists for the same category with overlapping dates.");
        }

        Category category = categoryRepo.findById(budgetDTO.getCategoryId())
                        .orElseThrow(() -> new CategoryNotFoundException("Category cannot be found"));

        budget.setCategory(category);
        budget.setAmount(budgetDTO.getAmount());
        budget.setStartDate(budgetDTO.getStartDate());
        budget.setEndDate(budgetDTO.getEndDate());
        Budget savedBudget = budgetRepo.save(budget);
        return convertToBudgetDTO(savedBudget);
    }

    @Override
    @Transactional
    public void deleteBudget(Long id) {
        Budget budget = budgetRepo.findById(id)
                .orElseThrow(() -> new BudgetNotFoundException("Budget cannot be found"));
        budgetRepo.delete(budget);
    }

    private BudgetDTO convertToBudgetDTO(Budget budget) {
        return new BudgetDTO(
                budget.getId(),
                budget.getAmount(),
                budget.getCategory().getId(),
                budget.getCategory().getName(),
                budget.getStartDate(),
                budget.getEndDate()
        );
    }
    //converts a list budget entities to list of budgetDTOs
    private List<BudgetDTO> convertToBudgetDTO(List<Budget> budget) {
        return budget.stream()
                .map(this::convertToBudgetDTO)
                .collect(Collectors.toList());
    }

    private Budget getBudgetEntityById(Long id) {
        return budgetRepo.findById(id)
                .orElseThrow(() -> new BudgetNotFoundException("Budget with ID - " + id + " not found"));
    }

}
