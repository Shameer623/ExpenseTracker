package com.cts.budgetbuddy.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExpenseResponseDTO {
    private Long id;
    private String description;
    private Double amount;
    private LocalDate date;
    private String categoryName;
    private Long userId;
    private String remainingBudget;

   
}
