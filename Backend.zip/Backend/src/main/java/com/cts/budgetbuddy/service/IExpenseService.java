package com.cts.budgetbuddy.service;

import java.time.LocalDate;
import java.util.List;

import com.cts.budgetbuddy.dto.ExpenseDTO;
import com.cts.budgetbuddy.dto.ExpenseResponseDTO;

public interface IExpenseService {
    ExpenseDTO createExpense(ExpenseDTO expenseDTO);

    List<ExpenseResponseDTO> getAllExpenses();

    ExpenseResponseDTO getExpenseById(Long id);

    List<ExpenseResponseDTO> getExpenseByCategory(Long id);

    List<ExpenseResponseDTO> getExpensesByDate(LocalDate date);

    List<ExpenseResponseDTO> getExpensesByRange(LocalDate startDate, LocalDate endDate);

    ExpenseDTO updateExpense(Long id, ExpenseDTO expenseDTO);

    void deleteExpense(Long id);
    
    List<ExpenseResponseDTO> getExpensesByUserId(Long userId);
}
