package com.cts.budgetbuddy.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.budgetbuddy.entity.User;

import java.util.List;

@Repository
public interface UserRepo extends JpaRepository<User, Long> {
    List<User> findByRole(User.Role role);

    User findByUsername(String username);
}
