package com.cts.budgetbuddy.service;

import org.springframework.http.ResponseEntity;

import com.cts.budgetbuddy.dto.LoginDTO;
import com.cts.budgetbuddy.dto.UserDTO;

import java.util.List;

public interface IUserService {
        UserDTO createUser(UserDTO userDTO);
        List<UserDTO> getAllUsers();
        List<UserDTO> getUserByRole(String role);
        UserDTO updateUser(Long id, UserDTO userDTO);
        void deleteUser(Long id);

    ResponseEntity<?> loginUser(LoginDTO loginDTO);
}
