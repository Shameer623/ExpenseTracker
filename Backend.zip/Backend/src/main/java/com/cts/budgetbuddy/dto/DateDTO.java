package com.cts.budgetbuddy.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class DateDTO {

    @JsonFormat(pattern = "yyyy-MM-dd") //ISO 8601 format
    private LocalDate date;

    
}

