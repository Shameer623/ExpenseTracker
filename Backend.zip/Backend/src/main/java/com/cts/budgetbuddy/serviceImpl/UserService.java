package com.cts.budgetbuddy.serviceImpl;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.budgetbuddy.dto.LoginDTO;
import com.cts.budgetbuddy.dto.LoginResponseDTO;
import com.cts.budgetbuddy.dto.UserDTO;
import com.cts.budgetbuddy.entity.User;
import com.cts.budgetbuddy.exception.UserAlreadyExistsException;
import com.cts.budgetbuddy.exception.UserNotFoundException;
import com.cts.budgetbuddy.repo.UserRepo;
import com.cts.budgetbuddy.security.JwtUtils;
import com.cts.budgetbuddy.service.IUserService;

import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class UserService implements IUserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private PasswordEncoder passwordEncoder;
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Override
    @Transactional
    public UserDTO createUser(UserDTO userDTO) {
    	//check if username already exists
    	if(userRepo.findByUsername(userDTO.getUsername()) != null) {
    		throw new UserAlreadyExistsException("Username already exists");
    	}
        User user = new User();
        user.setUsername(userDTO.getUsername());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        user.setRole(User.Role.valueOf(userDTO.getRole().toUpperCase()));
        User savedUser = userRepo.save(user);
        return convertToUserDTO(savedUser);
    }

    @Override
    public List<UserDTO> getAllUsers() {
        List<User> users = userRepo.findAll();
        if (users.isEmpty()) {
            throw new UserNotFoundException("User not found");
        }
        return users.stream()
                .map(this::convertToUserDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<UserDTO> getUserByRole(String role) {
        List<User> users = userRepo.findByRole(User.Role.valueOf(role.toUpperCase()));
        if (users.isEmpty()) {
            throw new UserNotFoundException("No users found with role: " + role);
        }
        return users.stream()
                .map(this::convertToUserDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public UserDTO updateUser(Long id, UserDTO userDTO) {
        User user = userRepo.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User Not Found"));
        user.setUsername(userDTO.getUsername());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        user.setRole(User.Role.valueOf(userDTO.getRole().toUpperCase()));
        User savedUser = userRepo.save(user);
        return convertToUserDTO(savedUser);
    }

    @Override
    @Transactional
    public void deleteUser(Long id) {
        if (!userRepo.existsById(id)) {
            throw new UserNotFoundException("User with ID " + id + " not found");
        }
        userRepo.deleteById(id);
    }

    @Override
    public ResponseEntity<?> loginUser(LoginDTO loginDTO) {
        User user = userRepo.findByUsername(loginDTO.getUsername());
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
        //System.out.println("password to be matched");
        logger.info("Attempting to match password for user: {}", loginDTO.getUsername());
        boolean passwordMatches = passwordEncoder.matches(loginDTO.getPassword(), user.getPassword());
        if (passwordMatches) {
            String token = jwtUtils.generateToken(user);
            return new ResponseEntity<>(new LoginResponseDTO(token, user.getRole().name()), HttpStatus.OK);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
    }

    private UserDTO convertToUserDTO(User user) {
        return new UserDTO(user.getId(), user.getUsername(),null,user.getRole().name());
    }
}
