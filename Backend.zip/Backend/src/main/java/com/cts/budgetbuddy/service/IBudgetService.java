package com.cts.budgetbuddy.service;

import java.util.List;

import com.cts.budgetbuddy.dto.BudgetDTO;

public interface IBudgetService {
    List<BudgetDTO> getAllBudgets();

    BudgetDTO setBudget(BudgetDTO budgetDTO);

    BudgetDTO getBudgetById(Long id);

    List<BudgetDTO> getBudgetByCategoryId(Long id);

    BudgetDTO updateBudget(Long id, BudgetDTO budgetDTO);

    void deleteBudget(Long id);
}
