package com.cts.budgetbuddy.serviceImpl;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.cts.budgetbuddy.dto.BudgetDTO;
import com.cts.budgetbuddy.dto.CategoryDTO;
//import com.cts.budgetbuddy.dto.ExpenseResponseDTO;
import com.cts.budgetbuddy.entity.Budget;
import com.cts.budgetbuddy.entity.Category;
import com.cts.budgetbuddy.entity.Expense;
import com.cts.budgetbuddy.exception.CategoryNotFoundException;
import com.cts.budgetbuddy.repo.BudgetRepo;
import com.cts.budgetbuddy.repo.CategoryRepo;
import com.cts.budgetbuddy.repo.ExpenseRepo;
import com.cts.budgetbuddy.service.ICategoryService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CategoryService implements ICategoryService {

    @Autowired
    private CategoryRepo categoryRepo;
//  @Autowired
//  private ExpenseService expenseService;
//  @Autowired
//  private BudgetService budgetService;
    @Autowired
    private ExpenseRepo expenseRepo;
    @Autowired
    private BudgetRepo budgetRepo;

    @Override
    @Transactional
    public CategoryDTO createCategory(CategoryDTO categoryDTO) {
    	if(categoryRepo.findByName(categoryDTO.getName()).isPresent()) {
    		throw new CategoryNotFoundException("Category already exists");
    	}
        Category category = new Category();
        category.setName(categoryDTO.getName());
        Category savedCategory = categoryRepo.save(category);
        return convertToCategoryDTO(savedCategory);
    }

    @Override
    public List<CategoryDTO> getAllCategories() {
        List<Category> category = categoryRepo.findAll();
        if (category.isEmpty()) {
            throw new CategoryNotFoundException("Category not found");
        }
        return convertToCategoryDTO(category);
    }

    @Override
    public CategoryDTO getCategoryById(Long id) {
        Category category = categoryRepo.findById(id).orElse(null);
        if (category == null) {
            throw new CategoryNotFoundException("Category with ID-" + id+ " is not found");
        }
        return convertToCategoryDTO(category);
    }

    @Override
    @Transactional
    public CategoryDTO updateCategory(Long id, CategoryDTO categoryDTO) {
        Category existingCategory = categoryRepo.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category with ID-" + id + " is not found"));

        existingCategory.setName(categoryDTO.getName());
        Category savedCategory = categoryRepo.save(existingCategory);
        return convertToCategoryDTO(savedCategory);
    }

    @Override
    @Transactional
    public void deleteCategory(Long id) {
        Category category = categoryRepo.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category with ID-" + id + " is not found"));

        List<Expense> expenseForCategoryID = expenseRepo.findByCategoryId(id);
        if (!expenseForCategoryID.isEmpty()) {
            throw new RuntimeException("Expenses found for the requested Category");
        }
        Optional<Budget> budgetForCategoryID = budgetRepo.findByCategoryId(id);
        if (!budgetForCategoryID.isEmpty()) {
            throw new RuntimeException("Budgets found for the requested Category");
        }

        categoryRepo.delete(category);
    }

    public CategoryDTO convertToCategoryDTO(Category category) {
        return new CategoryDTO(
                category.getId(),
                category.getName()
        );
    }

    public List<CategoryDTO> convertToCategoryDTO(List<Category> categories) {
        return categories.stream()
                .map(this::convertToCategoryDTO)
                .collect(Collectors.toList());
    }
}
