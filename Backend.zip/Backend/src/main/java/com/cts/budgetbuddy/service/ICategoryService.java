package com.cts.budgetbuddy.service;

import java.util.List;

import com.cts.budgetbuddy.dto.CategoryDTO;

public interface ICategoryService {
    CategoryDTO createCategory(CategoryDTO categoryDTO);

    List<CategoryDTO> getAllCategories();

    CategoryDTO getCategoryById(Long id);

    CategoryDTO updateCategory(Long id, CategoryDTO categoryDTO);

    void deleteCategory(Long id);
}
