package com.cts.budgetbuddy.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BudgetDTO {

    private Long id;

    @DecimalMin(value = "1.0", message = "Budget amount should be greater than Rs.1")
    private double amount;

    @NotNull(message = "Category ID cannot be null")
    private Long categoryId;
    private String categoryName;

    @NotNull(message = "Start date cannot be empty")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    @NotNull(message = "End date cannot be empty")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate;

}
