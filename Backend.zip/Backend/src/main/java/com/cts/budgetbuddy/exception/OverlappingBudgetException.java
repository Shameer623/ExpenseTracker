package com.cts.budgetbuddy.exception;

public class OverlappingBudgetException extends RuntimeException{
    public OverlappingBudgetException(String message){
        super(message);
    }
}
